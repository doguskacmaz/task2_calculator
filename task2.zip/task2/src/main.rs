use std::io;

fn main() {
    
    println!("Please enter the nominator");

    let mut num_1 = String :: new();
    io::stdin()
    .read_line(&mut num_1)
    .expect("failed to read");


   let num_1 : f64 =  match num_1.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Invalid input for the numerator.");
            return;
        }
    };



    println!("Please enter the operator name: sum, subtract, multiply, divide");

    let mut op = String ::new();
    io::stdin()
    .read_line(&mut op)
    .expect("failed to read");

    let operator: Operator =match op.trim().to_lowercase().as_str(){

        "sum" => Operator::Sum,
        "subtract" => Operator::Subtract,
        "multiply" => Operator::Multiply,
        "divide" => Operator::Divide,
        _ => {
            println!("Invalid operator.");
            return;
        }
    };
    
    
    
    
    println!("Please enter the denominator");

    
    let mut num_2 = String :: new();
    io::stdin()
    .read_line(&mut num_2)
    .expect("failed to read");

    
    let num_2: f64 = match num_2.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Invalid input for the denominator.");
            return;
        }
    };

    
    let result = operator.calculate(num_1, num_2);

    match result {
        Ok(r) => println!("Result: {}", r),
        Err(err) => println!("{}", err),
    }

   

    

}

enum Operator{
    Sum,
    Subtract,
    Multiply,
    Divide,
}




impl Operator{
    fn calculate(&self,num_1:f64,num_2:f64)-> Result<f64, String>{
        match self {
            Operator::Sum=> Ok (num_1 + num_2),
            Operator::Subtract => Ok (num_1 - num_2),
            
            Operator::Multiply=> Ok(num_1 * num_2),

            Operator::Divide => 
                if num_2 == 0.0 {
                    Err(String::from("Error: Division by zero!"))
                } else {
                    Ok(num_1 / num_2)
                },

            }
        }
   }

